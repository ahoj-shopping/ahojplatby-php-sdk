<h2>Termination page :(</h2>
<p>Toto je termination page pre objednavku cislo #<?php echo $_GET["orderNumber"]; ?>.</p>