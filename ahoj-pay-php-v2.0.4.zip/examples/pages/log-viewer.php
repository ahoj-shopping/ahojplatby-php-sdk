<textarea class="example-log-viewer">
<?php
if (file_exists($logFile)) {
    echo file_get_contents($logFile);
}
?>
</textarea>