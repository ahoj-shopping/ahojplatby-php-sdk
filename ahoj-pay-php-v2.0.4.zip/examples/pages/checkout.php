<?php

if (isset($_GET['delete-from-cart'])) {
    $simpleShopStorage->deleteCardItem($_GET['delete-from-cart']);
}

if (isset($_POST['add-to-cart'])) {
    $itemAddons = array();
    if (!empty($_POST['addon-select'])) {
        foreach ($_POST['addon-select'] as $key => $value) {
            $addon_index = $value;
            array_push($itemAddons, array(
                'id' => $_POST['addon-id'][$addon_index],
                'name' => $_POST['addon-name'][$addon_index],
                'price' => empty($_POST['addon-price'][$addon_index]) ? 0 : $_POST['addon-price'][$addon_index],
            ));
        }
    }
    $item = array(
        'id' => $_POST['product-id'],
        'name' => $_POST['product-name'],
        'price' => $_POST['product-price'],
        'count' => $_POST['product-count'],
        'typeText' => $_POST['product-typeText'],
        'nonMaterial' => isset($_POST["product-nonMaterial"]) ? true : false,
        'codeText' => array_values(array_filter($_POST['product-codeText'])),
        'commodityText' => array_values(array_filter($_POST['product-commodityText'])),
        'additionalServices' => $itemAddons
    );
    $simpleShopStorage->addToCartItem($item);
}

$cartItems = $simpleShopStorage->getCartItems();
$cartItemsTotal = $simpleShopStorage->getCartItemsTotalPrice();
// $isAhojPayAvailableForTotalPrice = $ahojPay->isAvailableForTotalPrice($cartItemsTotal);
$orderNumber = time();
$paymentMethods = $ahojPay->getPaymentMethods($cartItemsTotal);

?>
<h2>Pokladna</h2>
<h3>Kosik</h3>
<a href="./index.php?page=product">Pridat produkt +</a><br /><br />
<table class="example-cart">
    <thead>
        <tr>
            <th>ID</th>
            <th>Produkt</th>
            <th>Mnozstvo</th>
            <th>Cena za kus</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($cartItems as $index => $item) {
        ?>
            <tr>
                <td>
                    <?php echo $item["id"]; ?>
                </td>
                <td>
                    <strong><?php echo $item["name"]; ?></strong><br />
                    Typ: <?php echo $item["typeText"] ? $item["typeText"] : '-'; ?><br />
                    Virtual: <?php echo $item["nonMaterial"] ? 'ano' : 'nie'; ?><br />
                    Kody: <?php echo $item["codeText"] ? implode(',', $item["codeText"]) : '-'; ?><br />
                    Kategorie: <?php echo $item["commodityText"] ? implode(',', $item["commodityText"]) : '-'; ?>
                    <?php
                    if (isset($item["additionalServices"]) && count($item["additionalServices"]) > 0) {
                    ?>
                        <br />
                        Doplnujuce sluzby:
                        <ul class="margin-top-0 margin-bottom-0">
                            <?php
                            foreach ($item["additionalServices"] as $addonIndex => $addon) {
                            ?>
                                <li><?php echo $addon["id"]; ?> - <?php echo $addon["name"]; ?> - <?php echo $addon["price"]; ?> EUR</li>
                            <?php
                            }
                            ?>
                        </ul>
                    <?php
                    }
                    ?>
                </td>
                <td>
                    <input type="number" id="product-count-<?php echo $index; ?>" name="product-count[]" value="<?php echo $item["count"]; ?>"> ks
                </td>
                <td>
                    Produkt: <?php echo $item['price']; ?> EUR <br />
                    Sluzby: <?php echo SimpleShopStorage::calculateItemAddonsPrice($item); ?> EUR <br />
                </td>
                <td>
                    <a href="./index.php?page=checkout&delete-from-cart=<?php echo $index; ?>">Vymazat</a>
                </td>
            </tr>
        <?php
        }
        ?>

    </tbody>
    <tfoot>
        <tr class="example-cart-total">
            <td colspan="3">Spolu za produkty a sluzby:</td>
            <td colspan="2">
                <span id="example-cart-subtotal-price"><?php echo $cartItemsTotal; ?></span> EUR
            </td>
        </tr>
        <tr>
            <td colspan="3">Doprava:</td>
            <td colspan="2">
                <input type="number" id="deliveryFee" name="deliveryFee" value="0"> EUR
            </td>
        </tr>
        <tr class="example-cart-total">
            <td colspan="3">Spolu:</td>
            <td colspan="2">
                <span id="example-cart-total-price"><?php echo $cartItemsTotal; ?></span> EUR
            </td>
        </tr>
    </tfoot>
</table>

<div class="row">
    <div class="col-sm">
        <h3>Nastavenia objednavky</h3>
        <div class="row">
            <div class="col">
                <label for="fname">Cislo objednavky:</label>
            </div>
            <div class="col">
                <input type="text" id="orderNumber" name="orderNumber" value="<?php echo $orderNumber; ?>">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Registrovany eshop zakaznik:</label>
            </div>
            <div class="col">
                <input type="checkbox" id="registeredCustomer" name="registeredCustomer" value="yes">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Počet nákupov zákazníka:</label>
            </div>
            <div class="col">
                <input type="text" id="customerOrderCount" name="customerOrderCount" value="<?php echo rand(0, 5); ?>">
            </div>
        </div>
        <h3>Fakturacne udaje</h3>
        <div class="row">
            <div class="col">
                <label for="fname">Meno:</label>
            </div>
            <div class="col">
                <input type="text" id="firstName" name="firstName" value="Zákazník">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Priezvisko:</label>
            </div>
            <div class="col">
                <input type="text" id="lastName" name="lastName" value="Nakupujúci">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Email:</label>
            </div>
            <div class="col">
                <input type="text" id="email" name="email" value="dev<?php echo time(); ?>@ahoj.shopping">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Mobil:</label>
            </div>
            <div class="col">
                <input type="text" id="mobile" name="mobile" value="421944130665">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Ulica:</label>
            </div>
            <div class="col">
                <input type="text" id="street" name="street" value="Zochova">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Cislo domu:</label>
            </div>
            <div class="col">
                <input type="text" id="registerNumber" name="registerNumber" value="5">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Mesto:</label>
            </div>
            <div class="col">
                <input type="text" id="city" name="city" value="Bratislava">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">PSC:</label>
            </div>
            <div class="col">
                <input type="text" id="zipCode" name="zipCode" value="81103">
            </div>
        </div>
        <h3>Dorucovacia adresa</h3>
        <div class="row">
            <div class="col">
                <label for="fname">Sposob dorucenia:</label>
            </div>
            <div class="col">
                <input type="text" id="goodsDeliveryTypeText" name="goodsDeliveryTypeText" value="courier">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Nazov dodacej adresy:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryName" name="deliveryName" value="Domov">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Ulica:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryStreet" name="deliveryStreet" value="Hviezdoslavova">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Cislo domu:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryRegisterNumber" name="deliveryRegisterNumber" value="313">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Mesto:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryCity" name="deliveryCity" value="Senica">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">PSC:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryZipCode" name="deliveryZipCode" value="90501">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="lname">Krajina:</label>
            </div>
            <div class="col">
                <input type="text" id="deliveryCountry" name="deliveryCountry" value="SK">
            </div>
        </div>
        <br />
    </div>
    <div class="col-sm">
        <h3>Platobné metódy</h3>
        <ul class="example-cart-list">
            <li>
                <input type="radio" name="payment-method" id="card" value="card" <?php echo $isAhojPayAvailableForTotalPrice ? '' : ' checked '; ?> />
                <label for="card">Platba kartou</label>
            </li>

            <?php 
                foreach ($paymentMethods as $key => $value) {
                    ?>
                        <li id="ahojpay-method-item-<?php echo $value['promotionCode']; ?>" class="<?php echo $value['isAvailable'] ? "" : "disabled-item"; ?>">
                            <input type="radio" name="payment-method" id="<?php echo $value['promotionCode']; ?>" value="<?php echo $value['promotionCode']; ?>" <?php echo $value['isAvailable'] ? '  ' : ' disabled="disabled"'; ?> />
                            <label for="<?php echo $value['promotionCode']; ?>"><?php echo $value['name']; ?></label>
                            <?php
                            echo $ahojPay->generatePaymentMethodDescriptionHtml($cartItemsTotal, "ahojpay-description-" . $value['promotionCode'], $value['promotionCode']);
                            ?>
                        </li>
                    <?php
                }
            ?>
        </ul>
    </div>
</div>



<button type="button" id="submit-order">Objednat s povinnostou platby</button>
<script type="text/javascript">
    const createOrderEndpointUrl = "<?php echo "$currentUrl?action=$createOrderActionName"; ?>";
    const getCalculationsEndpointUrl = "<?php echo "$currentUrl?action=$getCalculationsActionName"; ?>";
    const cartItems = <?php echo json_encode($cartItems); ?>;
    const promotionCodes = <?php echo json_encode(array_map(function ($item) {return $item['promotionCode'];}, $paymentMethods)); ?>;
    let deliveryFee = 0;
    let total = 0;
    let subtotal = 0;

    function updatePaymentMethod(promotionCode) {
        const isAhojPayAvailable = ahojpay.isAvailableForTotalOrderPrice(subtotal, promotionCode);
        const paymentMethodItemElement = document.getElementById("ahojpay-method-item-" + promotionCode);
        const ahojpayRadioElement = document.getElementById(promotionCode);
        const cardRadioElement = document.getElementById("card");
        if (isAhojPayAvailable) {
            ahojpayRadioElement.removeAttribute("disabled");
            cardRadioElement.checked = false;
            ahojpayRadioElement.checked = true;

            if (paymentMethodItemElement.classList.contains("disabled-item")) {
                paymentMethodItemElement.classList.remove("disabled-item");
            }
        } else {
            ahojpayRadioElement.checked = false;
            cardRadioElement.checked = true;
            ahojpayRadioElement.setAttribute("disabled", "disabled");
            if (!paymentMethodItemElement.classList.contains("disabled-item")) {
                paymentMethodItemElement.classList.add("disabled-item");
            }
        }
    }

    function recalculateTotals() {
        // update JS data 
        const deliveryFeeInput = document.getElementById("deliveryFee");
        deliveryFee = Number(deliveryFeeInput.value === '' ? 0 : deliveryFeeInput.value);
        for (let index = 0; index < cartItems.length; index++) {
            const countInput = document.getElementById("product-count-" + index);
            cartItems[index].count = Number(countInput.value === '' ? 0 : countInput.value);
        }

        // recalculate
        total = deliveryFee;
        subtotal = 0;
        for (let index = 0; index < cartItems.length; index++) {
            const item = cartItems[index];
            const itemCount = Number(item.count);
            const itemPrice = itemCount * Number(item.price);
            total += itemPrice;
            subtotal += itemPrice;
            for (let indexAddon = 0; indexAddon < item.additionalServices.length; indexAddon++) {
                const addon = item.additionalServices[indexAddon];
                total += Number(addon.price) * itemCount;
                subtotal += Number(addon.price) * itemCount;
            }
        }

        // present data
        document.getElementById('example-cart-total-price').innerHTML = total;
        document.getElementById('example-cart-subtotal-price').innerHTML = subtotal;

        for (let index = 0; index < promotionCodes.length; index++) {
            const code = promotionCodes[index];
            updatePaymentMethod(code);
        }
    }

    function refreshPaymentMethodDescriptions() {
        const formData = new FormData();
        formData.append("productTotalPrice", total);
        const request = new XMLHttpRequest();
        request.onreadystatechange = function() {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    const response = JSON.parse(this.responseText);
                    promotionCodes.forEach(promotionCode => {
                        ahojpay.paymentMethodDescription(
                            total, 
                            ".ahojpay-description-" + promotionCode, 
                            promotionCode, 
                            response.find(calc => calc.promotionCode === promotionCode) || {}
                        );
                    });
                    return;
                }
                alert(this.responseText);
            }
        };
        request.open("POST", getCalculationsEndpointUrl, true);
        request.send(formData);
    }

    document.addEventListener('input', (e) => {
        if (e.target.getAttribute('type') == "number") {
            deliveryFee = Number(e.target.value === '' ? 0 : e.target.value);
            recalculateTotals();
            refreshPaymentMethodDescriptions();
        }
    });

    document.getElementById('submit-order').addEventListener('click', function(event) {
        const selectedPaymentMethodElement = document.querySelector('[name=payment-method]:checked');
        const selectedPaymentMethod = selectedPaymentMethodElement.value;

        if (selectedPaymentMethod === 'card') {
            alert('platba kartou :) skus predsa len Ahoj Pay');
            return;
        }

        const formData = new FormData();
        formData.append("orderNumber", document.getElementById("orderNumber").value);
        formData.append("eshopRegisteredCustomer", document.getElementById("registeredCustomer").checked);
        formData.append("eshopCustomerOrderCount", document.getElementById("customerOrderCount").value);
        formData.append("firstName", document.getElementById("firstName").value);
        formData.append("lastName", document.getElementById("lastName").value);
        formData.append("email", document.getElementById("email").value);
        formData.append("mobile", document.getElementById("mobile").value);
        formData.append("street", document.getElementById("street").value);
        formData.append("registerNumber", document.getElementById("registerNumber").value);
        formData.append("city", document.getElementById("city").value);
        formData.append("zipCode", document.getElementById("zipCode").value);
        formData.append("goodsDeliveryCosts", document.getElementById("deliveryFee").value || 0);
        formData.append("goodsDeliveryTypeText", document.getElementById("goodsDeliveryTypeText").value || 0);
        formData.append("deliveryStreet", document.getElementById("deliveryStreet").value);
        formData.append("deliveryRegisterNumber", document.getElementById("deliveryRegisterNumber").value);
        formData.append("deliveryCity", document.getElementById("deliveryCity").value);
        formData.append("deliveryZipCode", document.getElementById("deliveryZipCode").value);
        formData.append("deliveryCountry", document.getElementById("deliveryCountry").value);
        formData.append("goods", JSON.stringify(cartItems));
        formData.append("promotionCode", selectedPaymentMethod);
        const request = new XMLHttpRequest();
        request.onreadystatechange = function() {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    const response = JSON.parse(this.responseText);
                    ahojpay.openApplication(response.applicationUrl);
                    return;
                }
                alert(this.responseText);
            }
        };
        request.open("POST", createOrderEndpointUrl, true);
        request.send(formData);
    });
</script>