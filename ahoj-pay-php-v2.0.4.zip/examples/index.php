<?php
require_once "../lib/ahoj-pay.php";

require_once "./inc/simple-shop.php";


$simpleShopStorage = new SimpleShopStorage();
$currentUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["HTTP_HOST"] . explode("?", $_SERVER["REQUEST_URI"], 2)[0];
$notificationCallbackActionName = "ahojNotificationCallbackUrl";
$createOrderActionName = "createOrderAndReturnApplicationUrl";
$getCalculationsActionName = "getCalculations";
$logFile = dirname(__FILE__) . "/notifications.log";

try {
    $ahojPay = new Ahoj\AhojPay(array(
        "mode" => "test",
        "businessPlace" => "TEST_ESHOP",
        "eshopKey" => "1111111111aaaaaaaaaa2222",
        "notificationCallbackUrl" => "$currentUrl?action=$notificationCallbackActionName",
    ));
} catch (Exception $exp) {
    // proper error handling
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_GET["action"])) {
    if ($_GET["action"] === $notificationCallbackActionName) {
        $content = file_get_contents($logFile);
        $body = file_get_contents('php://input');
        file_put_contents($logFile, date("Y-m-d h:i:sa") . " - " . $body . "\n" . $content);
    }
    if ($_GET["action"] === $getCalculationsActionName) {
        $result = $ahojPay->getCalculations(isset($_POST["productTotalPrice"]) ? $_POST["productTotalPrice"] : 0);
        echo json_encode($result);
    }
    if ($_GET["action"] === $createOrderActionName) {
        $orderNumber = isset($_POST["orderNumber"]) ? $_POST["orderNumber"] : time();
        $applicationParams = array(
            "orderNumber" => $orderNumber,
            "completionUrl" => "$currentUrl?page=thankyou&orderNumber=$orderNumber",
            "terminationUrl" => "$currentUrl?page=terminate&orderNumber=$orderNumber",
            "eshopRegisteredCustomer" => isset($_POST["eshopRegisteredCustomer"]) ? true : false,
            "customer" => array(
                "firstName" => $_POST["firstName"],
                "lastName" => $_POST["lastName"],
                "contactInfo" => array(
                    "email" => $_POST["email"],
                    "mobile" => $_POST["mobile"],
                ),
                "permanentAddress" => array(
                    "street" => $_POST["street"],
                    "registerNumber" => $_POST["registerNumber"],
                    "city" => $_POST["city"],
                    "zipCode" => $_POST["zipCode"],
                )
            ),
            "product" => array(
                "goods" => json_decode($_POST['goods'], true),
                "goodsDeliveryTypeText" => $_POST["goodsDeliveryTypeText"],
                "goodsDeliveryCosts" => isset($_POST["goodsDeliveryCosts"]) ? $_POST["goodsDeliveryCosts"] : 0,
                "goodsDeliveryAddress" => array(
                    "name" => isset($_POST["deliveryName"]) ? $_POST["deliveryName"] : "",
                    "street" => isset($_POST["deliveryStreet"]) ? $_POST["deliveryStreet"] : $_POST["street"],
                    "registerNumber" => isset($_POST["deliveryRegisterNumber"]) ? $_POST["deliveryRegisterNumber"] : $_POST["registerNumber"],
                    "city" => isset($_POST["deliveryCity"]) ? $_POST["deliveryCity"] : $_POST["city"],
                    "zipCode" => isset($_POST["deliveryZipCode"]) ? $_POST["deliveryZipCode"] : $_POST["zipCode"],
                    "country" => isset($_POST["deliveryCountry"]) ? $_POST["deliveryCountry"] : $_POST["country"],
                )
            )
        );
        $promotionCode = isset($_POST["promotionCode"]) ? $_POST["promotionCode"] : Ahoj\AhojPay::PROMOTION_CODE_ODLOZTO;
        if (isset($_POST["eshopCustomerOrderCount"])) {
            $applicationParams['eshopCustomerOrderCount'] = $_POST["eshopCustomerOrderCount"];
        }

        try {
            $result = $ahojPay->createApplication($applicationParams, $promotionCode);
            echo json_encode($result);
        } catch (Exception $exp) {
            if ($exp instanceof Ahoj\InvalidArgumentException) {
                http_response_code(400);
                echo $exp->getMessage();
                exit();
            }
            if ($exp instanceof Ahoj\TotalPriceExceedsLimitsException) {
                http_response_code(400);
                echo "Celkova cena objednavky je prilis vysoka pre platobnu metodu AhojPay. Vyberte prosim iny sposob platby.";
                exit();
            }
            echo $exp->getMessage() ? $exp->getMessage() : 'Internal Server Error';
            http_response_code(500);
        }
    }
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Ahoj Pay Example E-shop</title>
    <link rel="stylesheet" href="./assets/css/normalize.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="./assets/css/bootstrap-grid.min.css">
</head>

<body>
    <div class="container example-wrapper">
        <div class="row example-header">
            <div class="col">
                <h1>Ahoj Pay Example E-shop</h1>

                <ul class="example-menu">
                    <li><a href="index.php?page=product">Produkt</a></li>
                    <li><a href="index.php?page=checkout">Pokladna</a></li>
                    <li><a href="index.php?page=log-viewer">Notification logs</a></li>
                </ul>
            </div>
        </div>
        <div class="row example-content">
            <div class="col">
                <?php
                // $ahojPay could be not defined in case of init errors in constructor
                try {
                    echo $ahojPay->generateInitJavaScriptHtml();
                } catch (Exception $exp) {
                }

                $page = isset($_GET["page"]) ? $_GET["page"] : 'product';

                $pageFile = "./pages/" . $page . ".php";
                if (file_exists($pageFile)) {
                    include_once $pageFile;
                } else {
                    echo "Page not found :(";
                }

                ?>
            </div>
        </div>
    </div>
</body>

</html>