<?php

$product = array(
    'id' => 'samsung-s21',
    'name' => 'Samsung galaxy S21',
    'price' => isset($_GET["price"]) ? $_GET["price"] : 100,
    'count' => 1,
    'additionalServices' => array()
);
$addonsMocks = array(
    array(
        'id' => 'poistenie',
        'name' => 'Poistenie proti kradezi',
        'price' => 5,
    ),
    array(
        'id' => 'vymena',
        'name' => 'Automaticka vymena',
        'price' => 20,
    ),
    array(
        'id' => 'zaruka',
        'name' => 'Predlzena zaruka',
        'price' => 10,
    )
);

$productBannerWrapperCssClass = Ahoj\AhojPay::PRODUCT_BANNER_CSS_CLASS;
$productTotalPrice = SimpleShopStorage::calculateItemTotalPrice($product, true);

?>
<form action="./index.php?page=checkout" method="post">
    <input type="hidden" id="add-to-cart" name="add-to-cart" value="1" />
    <div class="row">
        <div class="col-sm-4">
            <h2>Produkt</h2>
            <div class="row">
                <div class="col">
                    <label for="fname">ID:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-id" name="product-id" value="<?php echo $product['id']; ?>">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="fname">Nazov:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-name" name="product-name" value="<?php echo $product['name']; ?>">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="fname">Cena:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-price" name="product-price" value="<?php echo $product['price']; ?>">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="fname">Mnozstvo:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-count" name="product-count" value="<?php echo $product['count']; ?>">
                </div>
            </div>
        </div>
        <div class="col-sm-1">
        </div>
        <div class="col-sm">
            <h2>Doplnkove sluzby</h2>
            <table>
                <thead>
                    <tr>
                        <th>Pouzit</th>
                        <th>ID</th>
                        <th>Nazov</th>
                        <th>Cena [EUR]</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    for ($i = 0; $i < 5; $i++) {
                    ?>
                        <tr>
                            <td><input type="checkbox" class="addon-checkbox" id="addon-<?php echo $i; ?>-select" name="addon-select[]" value="<?php echo $i; ?>"></td>
                            <td><input type="text" id="addon-<?php echo $i; ?>-id" name="addon-id[]" value="<?php echo $addonsMocks[$i]['id']; ?>"></td>
                            <td><input type="text" id="addon-<?php echo $i; ?>-name" name="addon-name[]" value="<?php echo $addonsMocks[$i]['name']; ?>"></td>
                            <td><input type="text" id="addon-<?php echo $i; ?>-price" name="addon-price[]" value="<?php echo $addonsMocks[$i]['price']; ?>"></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <h2>Dalsie info o produkte</h2>
        </div>
        <div class="col-sm-4">
            <div class="row">
                <div class="col">
                    <label for="fname">Typ produktu:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-typeText" name="product-typeText" value="<?php echo $product['typeText']; ?>">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="fname">Virtualny produkt?:</label>
                </div>
                <div class="col">
                    <input type="checkbox" id="product-nonMaterial" name="product-nonMaterial" value="true">
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="row">
                <div class="col">
                    <label for="fname">Kody tovaru:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-0-codeText" name="product-codeText[]">
                    <input type="text" id="product-1-codeText" name="product-codeText[]">
                    <input type="text" id="product-2-codeText" name="product-codeText[]">
                    <input type="text" id="product-3-codeText" name="product-codeText[]">
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="row">
                <div class="col">
                    <label for="fname">Kategorie tovaru:</label>
                </div>
                <div class="col">
                    <input type="text" id="product-0-commodityText" name="product-commodityText[]">
                    <input type="text" id="product-1-commodityText" name="product-commodityText[]">
                    <input type="text" id="product-2-commodityText" name="product-commodityText[]">
                    <input type="text" id="product-3-commodityText" name="product-commodityText[]">
                </div>
            </div>
        </div>
    </div>
    <h2>Celkova cena produktu:
        <span id="example-product-total-price" class="product-price-wrapper">
            <?php echo $productTotalPrice; ?>
        </span> EUR
    </h2>
    <p>
        <?php
        // zobrazenie banneru hned po nacitani
        echo $ahojPay->generateProductBannerHtml($productTotalPrice);
        ?>
    </p>
    <a href="">
        <button type="submit">Pridat do kosika</button>
    </a>
</form>

<script type="text/javascript">
    let productTotalPrice = <?php echo $productTotalPrice; ?>;
    const productBannerCssClass = ".<?php echo $productBannerWrapperCssClass; ?>";
    const getCalculationsEndpointUrl = "<?php echo "$currentUrl?action=$getCalculationsActionName"; ?>";
    const item = <?php echo json_encode($product); ?>;

    function updateJsonModel() {
        const productPriceInput = document.getElementById("product-price");
        const productCountInput = document.getElementById("product-count");
        item.id = document.getElementById("product-id").value;
        item.name = document.getElementById("product-name").value;
        item.price = Number(productPriceInput.value === '' ? 0 : productPriceInput.value);
        item.count = Number(productCountInput.value === '' ? 0 : productCountInput.value);

        item.additionalServices = [];

        const allAddonCheckboxes = document.getElementsByClassName("addon-checkbox");
        for (let index = 0; index < allAddonCheckboxes.length; index++) {
            const checkboxInput = allAddonCheckboxes[index];
            if (checkboxInput.checked) {
                const priceInput = document.getElementById("addon-" + index + "-price");
                const price = Number(priceInput.value === '' ? 0 : priceInput.value);

                if (price > 0) {
                    item.additionalServices.push({
                        id: document.getElementById("addon-" + index + "-id").value,
                        name: document.getElementById("addon-" + index + "-name").value,
                        price: price
                    });
                }
            }
        }

        // calc totals
        productTotalPrice = item.price * item.count;
        for (let index = 0; index < item.additionalServices.length; index++) {
            const addon = item.additionalServices[index];
            productTotalPrice += addon.price * item.count;
        }
        // present data
        document.getElementById('example-product-total-price').innerHTML = productTotalPrice;
    }

    function refreshProductBanner() {
        const formData = new FormData();
        formData.append("productTotalPrice", productTotalPrice);
        const request = new XMLHttpRequest();
        request.onreadystatechange = function() {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    const response = JSON.parse(this.responseText);
                    ahojpay.productBanner(productTotalPrice, productBannerCssClass, response);
                    return;
                }
            }
        };
        request.open("POST", getCalculationsEndpointUrl, true);
        request.send(formData);
    }

    document.addEventListener('input', (e) => {
        updateJsonModel();
        refreshProductBanner();
    });
</script>