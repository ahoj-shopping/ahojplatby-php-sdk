<?php

class SimpleShopStorage
{
    const CART_ITEMS_KEY = 'cart_items';

    private $cartItems = array();

    function __construct()
    {
        session_start();
        if (!isset($_SESSION[self::CART_ITEMS_KEY])) {
            $_SESSION[self::CART_ITEMS_KEY] = array();
        }
        $this->loadData();
    }

    function addToCartItem($item)
    {
        array_push($this->cartItems, $item);
        $this->cartItems = array_values($this->cartItems);
        $this->persistData();
    }

    function deleteCardItem($index)
    {
        unset($this->cartItems[$index]);
        $this->cartItems = array_values($this->cartItems);
        $this->persistData();
    }

    function clearCartItems()
    {
        $this->cartItems = array();
        $this->persistData();
    }

    function getCartItems()
    {
        return $this->cartItems;
    }

    function getCartItemsCount()
    {
        return count($this->cartItems);
    }

    function getCartItemsTotalPrice()
    {
        if (count($this->cartItems) <= 0) {
            return 0;
        }
        $total = 0;
        foreach ($this->cartItems as $key => $item) {
            $total += SimpleShopStorage::calculateItemTotalPrice($item);
        }
        return $total;
    }

    static function calculateItemTotalPrice($item, $includeAddons = true)
    {
        $total = 0;
        $total += $item["count"] * $item["price"];
        if ($includeAddons) {
            $total += SimpleShopStorage::calculateItemAddonsTotalPrice($item);
        }
        return $total;
    }

    static function calculateItemAddonsPrice($item)
    {
        $total = 0;
        foreach ($item["additionalServices"] as $key => $addon) {
            $total += $addon["price"];
        }
        return $total;
    }

    static function calculateItemAddonsTotalPrice($item)
    {
        return SimpleShopStorage::calculateItemAddonsPrice($item) * $item['count'];
    }

    private function persistData()
    {
        $_SESSION[self::CART_ITEMS_KEY] = $this->cartItems;
    }

    private function loadData()
    {
        $this->cartItems = $_SESSION[self::CART_ITEMS_KEY];
        $this->cartItems = array_values($this->cartItems);
    }


    // // property declaration
    // public $var = 'a default value';

    // // method declaration
    // public function displayVar() {
    //     echo $this->var;
    // }
}
