<?php $simpleShopStorage->clearCartItems(); ?>
<h2>Completion page :)</h2>
<p>Dakujeme za nakup #<?php echo $_GET["orderNumber"]; ?>.</p>